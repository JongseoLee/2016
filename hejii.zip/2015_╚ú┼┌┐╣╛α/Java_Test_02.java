//<src/com/lge/test/Java_Test_02.java>

package com.lge.test;

import java.util.List;

import com.lge.entity.BookedHotel;
import com.lge.entity.Hotel;
import com.lge.exception.AlreadyBookedException;
import com.lge.exception.AlreadyCanceledException;
import com.lge.exception.InvalidNumberException;
import com.lge.service.HotelManagerService;
import com.lge.util.KeyboardUtil;


public class Java_Test_02 {

	/**
     * ���α׷� ���� �޼���
     * 
     * @param args
     */
    public static void main(String[] args) {
    	boolean loopFlag = true;

		HotelManagerService service = new HotelManagerService();

        while (loopFlag) {
            int input = displayMenu();
            switch (input) {
            case 1:
            	retrieveHotelList(service);
                break;
            case 2:
	            retrieveBookingList(service);
            	break;
            case 3:
            	bookHotel(service);
            	break;            
            case 4:
            	cancelBooking(service);
            	break;            
            case 0:
                loopFlag = false;
                break;
            default:
                System.out.println(":: Invalid menu number!");            
                break;
            }
        }
    }
    
    /**
     * ����ڰ� �Է��� �޴��� ���� �����´�.
     * 
     * @return ����� �Է� �޴� ��
     */
    public static int displayMenu() {
        System.out.println("\n============================================");
        System.out.println("            Hotel Booking System");
        System.out.println("============================================");
        System.out.println("1. Retrieve hotel list");
        System.out.println("2. Retrieve my booking list");
        System.out.println("3. Book a hotel");
        System.out.println("4. Cancel my booking");        
        System.out.println("0. Exit");
        System.out.print(">> Select menu : ");

        int sel = KeyboardUtil.inputNumber();
        
        return sel;
    }
    
    /**
     * ��ü ȣ�� ����Ʈ�� ����Ѵ�.
     * 
     * @param service	
     * 				ȣ�� �Ŵ��� ���� ��ü
     */
    public static void retrieveHotelList(HotelManagerService service) {    	
    	List<Hotel> hotelList = service.getHotelList();
        System.out.println(String.format("\n%-5s%-10s%-10s%-10s%-10s", "No.", "Name", "Price", "Loc", "Rooms"));
        System.out.println("--------------------------------------------");        
        
        int index = 0;
        for (Hotel hotel : hotelList) {
        	System.out.println(String.format("%-5s%s", ++index, hotel));
        }	       
    }
    
    /**
     * ����� ȣ���� ����Ʈ�� ����Ѵ�.
     * 
     * @param service	
     * 				ȣ�� �Ŵ��� ���� ��ü
     */
    public static void retrieveBookingList(HotelManagerService service) {
        
        List<BookedHotel> hotelList = null;

		hotelList = service.getMyBookingList();
		
        System.out.println(String.format("\n%-5s%-10s%-10s%-10s%-10s", "No.", "Name", "Price", "Loc", "Status"));
        System.out.println("--------------------------------------------");  
        
        
        int index = 0;
        for (BookedHotel hotel : hotelList) {
        	System.out.println(String.format("%-5s%s", ++index, hotel));        	
        }
    }
          
    /**
     * �� ��ġ ��ó ȣ���� ã�� ����� �� �Է¹��� ȣ���� ������ �����Ͽ� ����� ����Ѵ�.
     * 
     * @param service	
     * 				ȣ�� �Ŵ��� ���� ��ü
     */    
    public static void bookHotel(HotelManagerService service) {
    	System.out.print("> Input your location [1-25] : ");
        int locNum = KeyboardUtil.inputNumber();
        
        service.setCurrentLocation(locNum);    
        List<Hotel> findList = null;
		try {
			findList = service.getHotelListNearMyLoc();
		} catch (InvalidNumberException e) {
			System.out.println(e.getMessage());
			return;
		} 
		System.out.println(String.format("\n%-5s%-10s%-10s%-10s%-10s%-10s", "No.", "Name", "Price", "Loc", "Rooms", "Proximity"));
        System.out.println("-------------------------------------------------------");     
               
        int index = 0;
        for (Hotel hotel : findList) {
        	System.out.println(String.format("%-5s%s%-10s", ++index, hotel, hotel.getProximity(locNum)));        
        }
        
        System.out.print("\n> Select hotel to book [1-20] : ");
        int bookNum = KeyboardUtil.inputNumber();        
        
        try {
        	service.bookHotel(findList.get(bookNum-1));					
    	} catch (AlreadyBookedException e) {
			System.out.println(e.getMessage());
		} 
    }    
    
    /**
     * ���� ��Ҹ� �����ϰ� ��� ����� ����Ѵ�.
     * 
     * @param service	
     * 				ȣ�� �Ŵ��� ���� ��ü
     */
    public static void cancelBooking(HotelManagerService service) {
    	retrieveBookingList(service);        

        System.out.print("\n> Select hotel to cancel [1-20] : ");
        int sel = KeyboardUtil.inputNumber();
        
        try {
			service.cancelBooking(sel);
		} catch (InvalidNumberException e) {
			System.out.println(e.getMessage());	
		} catch (AlreadyCanceledException e) {
			System.out.println(e.getMessage());
		}
    }    
}

?
