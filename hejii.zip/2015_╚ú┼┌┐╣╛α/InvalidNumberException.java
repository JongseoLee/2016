//<src/com/lge/exception/InvalidNumberException.java>

package com.lge.exception;

public class InvalidNumberException extends Exception {
	
	public InvalidNumberException(String message) {
        super(message);
    }
	
	public InvalidNumberException() {
		this("\n:: Invalid Number!");
	}
}
