//<src/com/lge/exception/AlreadyCanceldException.java>

package com.lge.exception;

public class AlreadyCanceledException extends Exception {

	public AlreadyCanceledException(String message) {
        super(message);
    }
	
	public AlreadyCanceledException() {
		this("\n:: Cancel Failed! Already canceled hotel.");
	}
}
