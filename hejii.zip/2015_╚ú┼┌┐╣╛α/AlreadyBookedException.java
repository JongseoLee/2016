//<src/com/lge/exception/AlreadyBookedException.java>

package com.lge.exception;

public class AlreadyBookedException extends Exception {

	public AlreadyBookedException(String message) {
        super(message);
    }
	
	public AlreadyBookedException() {
		this("\n:: Booking Failed! Already booked hotel.");
	}
}
