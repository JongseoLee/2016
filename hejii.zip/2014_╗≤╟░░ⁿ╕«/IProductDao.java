//<src\com\lge\model/IProductDao.java>
package com.lge.model;

import java.util.ArrayList;

import com.lge.exception.ProductDuplicateException;
import com.lge.exception.ProductNotFoundException;
import com.lge.exception.ProductOutOfStockException;

public interface IProductDao {

    /**
     * Adding a new product
     * 
     * @param p
     *            - product to be added
     * @param quantity
     *            - initial quantity
     * @throws ProductDuplicateException
     *             - When the p's product code already exists.
     */
    public void addProduct(Product p, int quantity) throws ProductDuplicateException;

    /**
     * Getting a product containing specific code
     * 
     * @param code
     *            - code for getting product
     * @return product contains product code
     * @throws ProductNotFoundException
     *             - If there is no product containing the code
     */
    public Product getProduct(String code) throws ProductNotFoundException;

    /**
     * Delete a product containing the code
     * 
     * @param code
     *            - code for deleting product
     * @throws ProductNotFoundException
     *             - If there is no product containing the code
     */
    public void delete(String code) throws ProductNotFoundException;

    /**
     * Getting quantity of a product containing the code
     * 
     * @param code
     *            - code for deleting product
     * @return quantity of the product
     * @throws ProductNotFoundException
     *             - If there is no product containing the code
     */
    public int getQuantity(String code) throws ProductNotFoundException;

    /**
     * Change quantity of the product
     * 
     * @param code
     *            - The code of the product to be updated
     * @param quantity
     *            - amount of updating
     * @throws ProductNotFoundException
     *             - If there is no product containing the code
     * @throws ProductOutOfStockException
     *             - If out of stock in release case
     */
    public void changeQuantity(String code, int quantity) throws ProductNotFoundException, ProductOutOfStockException;

    /**
     * Searching product list containing the key
     * 
     * @param key
     *            - search keyword
     * @return List of product containing the key
     */
    public ArrayList<Product> searchProduct(String key);
}
