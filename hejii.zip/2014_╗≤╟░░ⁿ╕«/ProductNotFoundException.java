//<src\com\lge\exception/ProductNotFoundException.java>
package com.lge.exception;

/** Thrown to indicate that a product is not found in ProductDao */
@SuppressWarnings("serial")
public class ProductNotFoundException extends Exception {
    public ProductNotFoundException(String message) {
        super(message);
    }

    public ProductNotFoundException() {
        this(":: The product code does not exist!");
    }
}

