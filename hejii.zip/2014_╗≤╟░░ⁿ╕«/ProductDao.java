//<src\com\lge\model/ProductDao.java>

package com.lge.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;

import com.lge.exception.ProductDuplicateException;
import com.lge.exception.ProductNotFoundException;
import com.lge.exception.ProductOutOfStockException;

public class ProductDao implements IProductDao {
    private static ProductDao instance;

    // key=Product,value=Stock Quantity
    private HashMap<Product, Integer> productMap = new HashMap<Product, Integer>();

    private ProductDao() {
        productMap.put(new Product("P-1000", "PDP TV2", 455000), 20);
        productMap.put(new Product("P-2000", "LCD TV", 550000), 10);
        productMap.put(new Product("P-3000", "PDP BOBOS", 700000), 20);
        productMap.put(new Product("P-4000", "LCD SunShine", 750000), 10);
        productMap.put(new Product("P-5000", "Slim Dios", 1800000), 20);
        productMap.put(new Product("P-6000", "Dios", 1300000), 14);
        productMap.put(new Product("P-7000", "Art Dios", 2800000), 15);
        productMap.put(new Product("P-8000", "Art Dios II", 2700000), 10);
        productMap.put(new Product("P-9000", "French Dios", 2500000), 10);
    }

    public static ProductDao getInstance() {
        if (instance == null) {
            instance = new ProductDao();
        }
        return instance;
    }


    @Override
    public void addProduct(Product p, int quantity) throws ProductDuplicateException {
        
        
        // TODO : Write code here
        
        
    }


    @Override
    public Product getProduct(String code) throws ProductNotFoundException {
     
        
        // TODO : Write code here
        
        
        return null;
    }

    @Override
    public int getQuantity(String code) throws ProductNotFoundException {
        Iterator<Product> keys = productMap.keySet().iterator();

        while (keys.hasNext()) {
            Product p = keys.next();
            if (p.getCode().equals(code))
                return productMap.get(p);
        }
        throw new ProductNotFoundException();
    }
    
    @Override
    public void delete(String code) throws ProductNotFoundException {

        
        // TODO : Write code here
    
    
    }

    @Override
    public void changeQuantity(String code, int quantity) throws ProductNotFoundException, ProductOutOfStockException {
        
        
        // TODO : Write code here
        
        
    }

    @Override
    public ArrayList<Product> searchProduct(String key) {

        
        // TODO : Write code here
        
        
        return null;
    }

    // Getter of productMap
    public HashMap<Product, Integer> getProductMap() {
        return productMap;
    }
}
