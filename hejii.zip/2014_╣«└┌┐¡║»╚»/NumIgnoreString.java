//<src/com/lge/lang/NumIgnoreString.java>
package com.lge.lang;

public class NumIgnoreString {

    private String str;

    public NumIgnoreString(String str) {
        this.str = str;
    }

    /**
     * Causes this character sequence to be replaced by the reverse of the
     * sequence based on ignoring numbers.
     * 
     * @return revered string
     */
    public String reverse() {

        
        // TODO : Write code here

        
        return "";
    }
}
