//<src/com/lge/test/Java_Test_01.java>
package com.lge.test;

import java.util.Scanner;

import com.lge.lang.NumIgnoreString;

public class Java_Test_01 {

    public static void main(String[] args) throws Exception {

        boolean loopFlag = true;

        while (loopFlag) {
            int input = displayMenu();
            switch (input) {
            case 1:
                reverseString();
                break;
            case 2:
                compareString();
                break;
            case 0:
                loopFlag = false;
                break;
            default:
                break;
            }
        }
    }

    /** Displaying menu */
    private static int displayMenu() {
        System.out.println("\n===============================================");
        System.out.println("     String Reversing And Comparing Utility");
        System.out.println("===============================================");
        System.out.println("1. Reverse String");
        System.out.println("2. Compare String");
        System.out.println("0. Exit");
        System.out.print(">> Select menu : ");

        Scanner scanner = new Scanner(System.in);
        return scanner.nextInt();
    }

    /** Reverse string */
    private static void reverseString() throws Exception {
        System.out.println();
        System.out.print("> Input String : ");

        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();

        NumIgnoreString myString = new NumIgnoreString(input);
        System.out.println(":: Reversed String : " + myString.reverse());
        System.out.println();
    }

    /** Comparing two strings */
    private static void compareString() throws Exception {
        Scanner scanner = new Scanner(System.in);
        System.out.println();
        System.out.print("> Input String1 : ");
        String input1 = scanner.nextLine();
        System.out.print("> Input String2 : ");
        String input2 = scanner.nextLine();

        NumIgnoreString myString1 = new NumIgnoreString(input1);
        NumIgnoreString myString2 = new NumIgnoreString(input2);

        if (myString1.equals(myString2)) {
            System.out.println(":: Compared Result : Matched!");
        } else {
            System.out.println(":: Compared Result : Not Matched!");
        }

        System.out.println();
    }
}
